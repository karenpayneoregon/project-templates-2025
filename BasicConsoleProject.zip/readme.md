﻿# About

Provides a basic project structure and classes to generate data. Generation of data resides in several folders named `DataGeneration`.
