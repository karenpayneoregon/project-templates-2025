﻿using $safeprojectname$.Classes.Configuration;
using $safeprojectname$.Classes.DataGeneration.BogusOperations;

namespace $safeprojectname$;
internal partial class Program
{
    static void Main(string[] args)
    {
        SpectreConsoleHelpers.ExitPrompt();
    }
}
